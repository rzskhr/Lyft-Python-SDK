
PUBLIC_AUTH_URL    = "https://api.lyft.com/oauth/token"
USER_AUTH_URL      = "https://api.lyft.com/oauth/authorize"
AUTH_REVOKE_URL    = "https://api.lyft.com/oauth/revoke_refresh_token"
RIDE               = "https://api.lyft.com/v1/rides"
